/******************************************************************************
 *
 * COPYRIGHT:
 *   Copyright (c)  2005-2010   Source Photonics Inc.    All rights reserved.
 *
 *   This is unpublished proprietary source code of Source Photonics Inc.
 *   The copyright notice above does not evidence any actual or intended
 *   publication of such source code.
 *
 * FILE NAME:
 *   main.c
 * DESCRIPTION:
 *   N/A
 * HISTORY:
 *   2010.10.14        Panda.Xiong         Create
 *
*****************************************************************************/

#include <stdio.h>
#include <math.h>
#include "typedefs.h"
#include "softfloat.h"


#define DEBUG_ENABLE    1


#if DEBUG_ENABLE
 #define DBG_PRT(...)   printf(__VA_ARGS__)
#else
 #define DBG_PRT(...)   /* do nothing */
#endif


typedef struct
{
    uint32  RSSI_AD;
    float32 RSSI_C0;
    float32 RSSI_C1;
    float32 RSSI_C2;
    float32 RSSI_C3;
    float32 RSSI_C4;
} RSSI_T;


uint32 RSSI_Calibrate(const RSSI_T  *pRSSI)
{
    float32 vADC = int32_to_float32(pRSSI->RSSI_AD);
    float32 RSSI;
    float32 raw;
    int32   RSSI_val;

  #if DEBUG_ENABLE
    float  *pf_RSSI    = (float *)&RSSI;
    float  *pf_raw     = (float *)&raw;
    float  *pf_RSSI_C4 = (float *)&(pRSSI->RSSI_C4);
    float  *pf_RSSI_C3 = (float *)&(pRSSI->RSSI_C3);
    float  *pf_RSSI_C2 = (float *)&(pRSSI->RSSI_C2);
    float  *pf_RSSI_C1 = (float *)&(pRSSI->RSSI_C1);
    float  *pf_RSSI_C0 = (float *)&(pRSSI->RSSI_C0);
  #endif

    DBG_PRT("\n\r RSSI_AD = %#04X = %d", pRSSI->RSSI_AD, pRSSI->RSSI_AD);
    DBG_PRT("\n\r RSSI_C4 = %#08X = %g", pRSSI->RSSI_C4, *pf_RSSI_C4);
    DBG_PRT("\n\r RSSI_C3 = %#08X = %g", pRSSI->RSSI_C3, *pf_RSSI_C3);
    DBG_PRT("\n\r RSSI_C2 = %#08X = %g", pRSSI->RSSI_C2, *pf_RSSI_C2);
    DBG_PRT("\n\r RSSI_C1 = %#08X = %g", pRSSI->RSSI_C1, *pf_RSSI_C1);
    DBG_PRT("\n\r RSSI_C0 = %#08X = %g", pRSSI->RSSI_C0, *pf_RSSI_C0);
    DBG_PRT("\n\r");

    RSSI = pRSSI->RSSI_C0;
    DBG_PRT("\n\r RSSI_C0");
    DBG_PRT("\n\r = %#08X = %f", RSSI, *pf_RSSI);
    DBG_PRT("\n\r");

    raw  = vADC;
    RSSI = float32_add(RSSI, float32_mul(raw, pRSSI->RSSI_C1));
    DBG_PRT("\n\r RSSI_C0");
    DBG_PRT("\n\r     + RSSI_C1 * pow(RSSI_AD, 1)");
    DBG_PRT("\n\r = %#08X = %f", RSSI, *pf_RSSI);
    DBG_PRT("\n\r");

    raw  = float32_mul(raw, vADC);
    RSSI = float32_add(RSSI, float32_mul(raw, pRSSI->RSSI_C2));
    DBG_PRT("\n\r RSSI_C0");
    DBG_PRT("\n\r     + RSSI_C1 * pow(RSSI_AD, 1)");
    DBG_PRT("\n\r     + RSSI_C2 * pow(RSSI_AD, 2)");
    DBG_PRT("\n\r = %#08X = %f", RSSI, *pf_RSSI);
    DBG_PRT("\n\r");

    raw  = float32_mul(raw, vADC);
    RSSI = float32_add(RSSI, float32_mul(raw, pRSSI->RSSI_C3));
    DBG_PRT("\n\r RSSI_C0");
    DBG_PRT("\n\r     + RSSI_C1 * pow(RSSI_AD, 1)");
    DBG_PRT("\n\r     + RSSI_C2 * pow(RSSI_AD, 2)");
    DBG_PRT("\n\r     + RSSI_C3 * pow(RSSI_AD, 3)");
    DBG_PRT("\n\r = %#08X = %f", RSSI, *pf_RSSI);
    DBG_PRT("\n\r");

    raw  = float32_mul(raw, vADC);
    RSSI = float32_add(RSSI, float32_mul(raw, pRSSI->RSSI_C4));
    DBG_PRT("\n\r RSSI_C0");
    DBG_PRT("\n\r     + RSSI_C1 * pow(RSSI_AD, 1)");
    DBG_PRT("\n\r     + RSSI_C2 * pow(RSSI_AD, 2)");
    DBG_PRT("\n\r     + RSSI_C3 * pow(RSSI_AD, 3)");
    DBG_PRT("\n\r     + RSSI_C4 * pow(RSSI_AD, 4)");
    DBG_PRT("\n\r = %#08X = %f", RSSI, *pf_RSSI);
    DBG_PRT("\n\r");

    RSSI_val = float32_to_int32_round_to_zero(RSSI);
    if (RSSI_val < 0)
    {
        /* if RSSI value is less than 0, assume no RxPower */
        RSSI_val = 0;
    }

    return (uint32)RSSI_val;
}


int main(void)
{
    RSSI_T  rssi;
    uint32  rssi_val;
    double  rssi_mW;
    double  rssi_dBm;

    rssi.RSSI_AD = 0x0186;
    rssi.RSSI_C4 = 0xA9A8A049;
    rssi.RSSI_C3 = 0x319EA29D;
    rssi.RSSI_C2 = 0x381427C9;
    rssi.RSSI_C1 = 0x3E1A3686;
    rssi.RSSI_C0 = 0x3F38857D;
    rssi_val = RSSI_Calibrate(&rssi);   /* unit of 0.1uW */
    rssi_mW  = (double)rssi_val /10000; /* unit of mW    */
    rssi_dBm = 10 * log10(rssi_mW);     /* unit of dBm   */

    printf("\n\r RxPower = %#04X = %f (mW) = %f (dBm) \n",
           rssi_val, rssi_mW, rssi_dBm);

    system("pause");
    return 0;
}

