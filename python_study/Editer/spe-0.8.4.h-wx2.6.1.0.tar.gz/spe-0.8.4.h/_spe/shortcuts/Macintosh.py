"""Mac shortcuts for SPE"""

keys = {
    'Save As'       : 'Ctrl+Shift+S',
    'Redo'          : 'Ctrl+Shift+Z',
    'Find Next'     : 'Ctrl+G', # not very logical, but usual on the Mac
    'Go to line'    : 'Ctrl+J', # "Jump"
} 