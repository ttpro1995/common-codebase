#(c)www.stani.be
import _spe.info
INFO=_spe.info.copy()

INFO['description']=\
"""Images, made as a package to easily get file information."""

__doc__=INFO['doc']%INFO
#_______________________________________________________________________________