python2.2 YOUR_PATH_TO_XRCED/xrced.py $*
