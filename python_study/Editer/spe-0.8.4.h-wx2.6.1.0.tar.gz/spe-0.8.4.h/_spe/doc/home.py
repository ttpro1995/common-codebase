import webbrowser
webbrowser.open('http://www.stani.be/python/spe/blog')