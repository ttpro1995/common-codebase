#
# chmod this file securely and be sure to remove the default users
#
users = {
    "frodo" : "1ring",
    "yossarian" : "catch22",
    "ayla" : "jondalar",
}

