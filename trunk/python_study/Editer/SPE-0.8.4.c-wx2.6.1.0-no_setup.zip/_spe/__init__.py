##import info
##INFO=info.copy()
##INFO['description']=\
##"""This is the main spe application."""
##__doc__=INFO['doc']%INFO

def main():
    import SPE
    
if __name__ == '__main__': main()
    
