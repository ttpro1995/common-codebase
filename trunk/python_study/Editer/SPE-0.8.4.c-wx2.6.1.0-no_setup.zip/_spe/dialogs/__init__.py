#(c)www.stani.be                                                                
import _spe.info
INFO=_spe.info.copy()

INFO['description']=\
"""This package contains various dialogs used by spe."""

__doc__=INFO['doc']%INFO

