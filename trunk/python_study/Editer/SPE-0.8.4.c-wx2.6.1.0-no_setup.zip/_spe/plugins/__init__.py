#(c)www.stani.be                                                                
import _spe.info
INFO=_spe.info.copy()

INFO['description']=\
"""This package contains various contributions for spe."""

__doc__=INFO['doc']%INFO

