extern void AT91F_DBGU_Printk(char *);

extern char _stext,_etext,_sdata,_edata;

#define BOOT_VERSION	"k9-Boot 1.0"

#define SRC 0x10020000
#define DST 0x20F00000
#define LEN    0x20000

void boot() {
  int i;
  char* ptr=(char*)DST;
  for(i=0;i<LEN;i++) ptr[i]=0;
  AT91F_DBGU_Printk ("\n\n\r"BOOT_VERSION" (" __DATE__ " - " __TIME__ ")\n\r");
  AT91F_DBGU_Printk("\n\r Copy k9-Uboot.bin from 0x10020000 to 0x20F00000...\n\n\r");
 /**************************************************************************/ 
  //decompress_image(SRC,DST,LEN);
#if 0
  void* memcpy(void* __dest, const void* __src, size_t __n)
{
	int i;
	char *d = (char *)__dest, *s = (char *)__src;

	for (i=0;i<__n;i++) d[i] = s[i];
}
#endif
   
   memcpy(DST,SRC,LEN);
 
  /**************************************************************************/
  
  
  AT91F_DBGU_Printk("\n\rEnter k9-Uboot \n\rBoot Begin from 0x20F00000...\n\n\r");
   asm("mov pc,%0" : : "r" (DST));
};

void recover(char* s) {
  for(;;);
};
