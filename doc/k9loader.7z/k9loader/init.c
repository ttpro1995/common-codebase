/*----------------------------------------------------------------------------	*/
/*         ATMEL Microcontroller Software Support  -  ROUSSET  -		*/
/*----------------------------------------------------------------------------	*/
/* The software is delivered "AS IS" without warranty or condition of any	*/
/* kind, either express, implied or statutory. This includes without		*/
/* limitation any warranty or condition with respect to merchantability or	*/
/* fitness for any particular purpose, or against the infringements of		*/
/* intellectual property rights of others.					*/
/*----------------------------------------------------------------------------	*/
/* File Name           : init.c							*/
/* Object              : Low level initialisations written in C			*/
/* Creation            : ODi   06/26/2002					*/
/*----------------------------------------------------------------------------	*/

#include "main.h"

#define AT91C_BASE_SDRAM	0x20000000
#define AT91C_MASTER_CLOCK	48000000
#define AT91C_BAUD_RATE		115200

/*----------------------------------------------------------------------------	*/
/* \fn    AT91F_DBGU_Printk							*/
/* \brief This function is used to send a string through the DBGU channel (Very low level debugging) */
/*----------------------------------------------------------------------------	*/
void AT91F_DBGU_Printk(
	char *buffer) // \arg pointer to a string ending by \0
{
	while(*buffer != '\0') {
		while (!AT91F_US_TxReady((AT91PS_USART)AT91C_BASE_DBGU));
		AT91F_US_PutChar((AT91PS_USART)AT91C_BASE_DBGU, *buffer++);
	}
}

/*----------------------------------------------------------------------------	*/
/* \fn    AT91F_DataAbort							*/
/* \brief This function reports an Abort					*/
/*----------------------------------------------------------------------------	*/
void AT91F_SpuriousHandler()
{
	AT91F_DBGU_Printk("-F- Spurious Interrupt detected\n\r");
	while (1);
}


/*----------------------------------------------------------------------------	*/
/* \fn    AT91F_DataAbort							*/
/* \brief This function reports an Abort					*/
/*----------------------------------------------------------------------------	*/
void AT91F_DataAbort()
{
	AT91F_DBGU_Printk("-F- Data Abort detected\n\r");
	while (1);
}

/*----------------------------------------------------------------------------	*/
/* \fn    AT91F_FetchAbort							*/
/* \brief This function reports an Abort					*/
/*----------------------------------------------------------------------------	*/
void AT91F_FetchAbort()
{
	AT91F_DBGU_Printk("-F- Prefetch Abort detected\n\r");
	while (1);
}

/*----------------------------------------------------------------------------	*/
/* \fn    AT91F_Undef								*/
/* \brief This function reports an Abort					*/
/*----------------------------------------------------------------------------	*/
void AT91F_Undef()
{
	AT91F_DBGU_Printk("-F- Undef detected\n\r");
	while (1);
}

/*----------------------------------------------------------------------------	*/
/* \fn    AT91F_UndefHandler							*/
/* \brief This function reports that no handler have been set for current IT	*/
/*----------------------------------------------------------------------------	*/
void AT91F_UndefHandler()
{
	AT91F_DBGU_Printk("-F- Undef detected\n\r");
	while (1);
}


/*--------------------------------------------------------------------------------------*/
/* Function Name       : AT91F_InitSDRAM						*/
/* Object              : Initialize the SDRAM						*/
/*--------------------------------------------------------------------------------------*/

/***********************************define 16bitBUS SDRAM********************************/
#if 0
#define SDRAMC_MR_16BIT (1L<<4)

void AT91F_InitSDRAM()
{
	volatile int *pSDRAM = (int *)AT91C_BASE_SDRAM;

	/* Configure PIOC as peripheral (D16/D31) */
	AT91F_PIO_CfgPeriph( AT91C_BASE_PIOC, 0xFFFF0000, 0);

	/*Setup MEMC to support all connected memories (CS0 = FLASH; CS1=SDRAM)*/
	AT91C_BASE_EBI->EBI_CSA = AT91C_EBI_CS1A;

	/*Init SDRAM*/
	AT91C_BASE_SDRC->SDRC_CR = 0x2188c154;
	AT91C_BASE_SDRC->SDRC_MR = 0x02 | SDRAMC_MR_16BIT;
	*pSDRAM = 0;
	AT91C_BASE_SDRC->SDRC_MR = 0x04 | SDRAMC_MR_16BIT;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;

	AT91C_BASE_SDRC->SDRC_MR = 0X03 | SDRAMC_MR_16BIT;
	*(pSDRAM + 0x80) = 0;

	AT91C_BASE_SDRC->SDRC_TR= 0x2e0;
	*pSDRAM = 0;

	AT91C_BASE_SDRC->SDRC_MR = 0x00 | SDRAMC_MR_16BIT;
	*pSDRAM = 0;

}
#endif

/***********************************define 32bitBUS SDRAM********************************/
#if 1
void AT91F_InitSDRAM()
{
	volatile int *pSDRAM = (int *)AT91C_BASE_SDRAM;

	/* Configure PIOC as peripheral (D16/D31) */
	AT91F_PIO_CfgPeriph( AT91C_BASE_PIOC, 0xFFFF0000, 0);

	/*Setup MEMC to support all connected memories (CS0 = FLASH; CS1=SDRAM)*/
	AT91C_BASE_EBI->EBI_CSA = AT91C_EBI_CS1A;

	/*Init SDRAM*/
	AT91C_BASE_SDRC->SDRC_CR = 0x2188c154; //����0x2188c155
	AT91C_BASE_SDRC->SDRC_MR = 0x02;
	*pSDRAM = 0;
	AT91C_BASE_SDRC->SDRC_MR = 0x04;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;
	*pSDRAM = 0;

	AT91C_BASE_SDRC->SDRC_MR = 0x03;
	*(pSDRAM + 0x80) = 0;

	AT91C_BASE_SDRC->SDRC_TR= 0x2e0;
	*pSDRAM = 0;

	AT91C_BASE_SDRC->SDRC_MR = 0;
	*pSDRAM = 0;

}
#endif
/*----------------------------------------------------------------------------*/
/* \fn    AT91F_InitFlash							*/
/* \brief This function performs very low level HW initialization		*/
/*----------------------------------------------------------------------------*/
void AT91F_InitFlash()
{
#if 0
	AT91C_BASE_MC->MC_PUIA[0] = AT91C_MC_PROT_PNAUNA;
	AT91C_BASE_MC->MC_PUP = 0;
	AT91C_BASE_MC->MC_PUER = 0;	/* Memory controller protection unit disable */
	AT91C_BASE_MC->MC_ASR = 0;  /* read only! */
	AT91C_BASE_MC->MC_AASR = 0; /* read only! */

	/* Setup MEMC to support CS0=Flash */
	AT91C_BASE_EBI->EBI_CSA |= AT91C_EBI_CS0A_SMC;
	AT91C_BASE_EBI->EBI_CFGR = (AT91C_EBI_DBPUC & 0x00) | (AT91C_EBI_EBSEN & 0x00);
#endif

	/* Setup Flash */
	/* com set CS0 cs for flash 16bits databus nws=8, wsen=1, tdf=8, acss=3*/
	//AT91C_BASE_SMC2->SMC2_CSR[0] = 0x00003284;
	AT91C_BASE_SMC2->SMC2_CSR[0] = 0x00003288;

	//AT91C_BASE_SMC2->SMC2_CSR[0] = (8) | AT91C_SMC2_WSEN
	//								| (AT91C_SMC2_TDF & 0x200) | AT91C_SMC2_BAT | AT91C_SMC2_DBW_16;
}

/*----------------------------------------------------------------------------	*/
/* \fn    AT91F_LowLevelInit							*/
/* \brief This function performs very low level HW initialization		*/
/*----------------------------------------------------------------------------	*/
void AT91F_LowLevelInit(void)
{
	/* Init Interrupt Controller */
	AT91F_AIC_Open(
		AT91C_BASE_AIC,          /* pointer to the AIC registers	*/
		AT91C_AIC_BRANCH_OPCODE, /* IRQ exception vector */
		AT91F_UndefHandler,      /* FIQ exception vector */
		AT91F_UndefHandler,      /* AIC default handler */
		AT91F_SpuriousHandler,   /* AIC spurious handler */
		0);                      /* Protect mode */

	/* Perform 8 End Of Interrupt Command to make s�re AIC will not Lock out nIRQ */
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);
	AT91F_AIC_AcknowledgeIt(AT91C_BASE_AIC);

	AT91F_AIC_SetExceptionVector((unsigned int *)0x0C, AT91F_FetchAbort);
	AT91F_AIC_SetExceptionVector((unsigned int *)0x10, AT91F_DataAbort);
	AT91F_AIC_SetExceptionVector((unsigned int *)0x4, AT91F_Undef);

	//AT91F_InitFlash();

	/* Initialize the SDRAM */
	AT91F_InitSDRAM();

	/* Open PIO for DBGU */
	AT91F_DBGU_CfgPIO();

	/* Configure DBGU */
	AT91F_US_Configure (
		(AT91PS_USART) AT91C_BASE_DBGU,  /* DBGU base address */
		AT91C_MASTER_CLOCK,              /* 48 MHz */
		AT91C_US_ASYNC_MODE,             /* mode Register to be programmed */
		AT91C_BAUD_RATE ,                /* baudrate to be programmed */
		0);                              /* timeguard to be programmed */

	/* Enable Transmitter */
	AT91F_US_EnableTx((AT91PS_USART)AT91C_BASE_DBGU);
	/* Enable Receiver */
	AT91F_US_EnableRx((AT91PS_USART)AT91C_BASE_DBGU);

	AT91F_DBGU_Printk("\n\r-I- AT91F_LowLevelInit(): Debug channel initialized\n\r");
}

