//*----------------------------------------------------------------------------
//*         ATMEL Microcontroller Software Support  -  ROUSSET  -
//*----------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*----------------------------------------------------------------------------
//* File Name           : main.c
//* Object              : main application written in C
//* Creation            : FB   24/10/2002
//*
//*----------------------------------------------------------------------------

extern void AT91F_DBGU_Printk(char *);

int main()
{
	AT91F_DBGU_Printk("\n\rBasicBoot Successfull: Enter main()\n\r");
	while (1);
}