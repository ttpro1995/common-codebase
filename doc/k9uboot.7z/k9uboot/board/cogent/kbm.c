/* keyboard/mouse not implemented yet */

int cma_kbm_not_implemented = 1;
